# 数据容器文件

import scrapy

class SpiderItem(scrapy.Item):
    pass

class YinyuexinxiItem(scrapy.Item):
    # 标题
    title = scrapy.Field()
    # 图片
    picture = scrapy.Field()
    # 作者
    zuozhe = scrapy.Field()
    # 详情地址
    xqdz = scrapy.Field()
    # 收藏数
    shoucang = scrapy.Field()
    # 分享数
    share = scrapy.Field()
    # 评论数
    pinglun = scrapy.Field()
    # 播放数
    bofang = scrapy.Field()
    # 介绍
    jieshao = scrapy.Field()
    # 歌曲列表数
    gqlb = scrapy.Field()

