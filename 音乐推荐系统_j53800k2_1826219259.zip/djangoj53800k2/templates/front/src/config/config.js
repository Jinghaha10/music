export default {
    baseUrl: 'http://localhost:8080/djangoj53800k2/',
	name: '/djangoj53800k2',
    indexNav: [
        {
            name: '音乐信息',
            url: '/index/yinlexinxi'
        },
        {
            name: '公告信息',
            url: '/index/news'
        },
    ]
}
