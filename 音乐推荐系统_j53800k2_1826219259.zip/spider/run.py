# 运行文件

# from scrapy.cmdline import execute

# execute('scrapy crawl collectSpider'.split())

import os

os.system("scrapy crawl yinyuexinxiSpider")
